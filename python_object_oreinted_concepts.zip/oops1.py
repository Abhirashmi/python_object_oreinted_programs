class Student:
    pass

abhi=Student()
rashmi=Student()

print(abhi,rashmi)


class Student:
    pass


harry = Student()
larry = Student()

harry.name = "Harry"
harry.std = 12
harry.section = 1
larry.std = 9
larry.subjects = ["hindi", "physics"]
print(harry.section, larry.subjects)




