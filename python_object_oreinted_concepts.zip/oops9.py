class Dad:
    basketball=1



class Son(Dad):
    football=2
    dance=22
    def can_dance(self):
        print("yess i can dance but my father cant because he only plays basketball ")


class Grand_son(Son):
    dance = 44
    def can_dance(self):
        print("yess i can dance cause my father use to dance :)")

dada=Dad()
beta=Son()
potaa=Grand_son()
potaa.can_dance()
print(potaa.basketball)