class Employee:
    no_of_leaves = 8

    def __init__(self,aname,asal,arole):
        self.name=aname
        self.salary=asal
        self.role=arole

    # def print_det(self):
    #     return f"name is {self.name} , Salary is {self.salary}.Role is {self.role}"

harry = Employee("harry",66666,"teacher")
rohan = Employee("rohan",99999999,"principal")

# harry.name = "Harry"
# harry.salary = 455
# harry.role = "Instructor"
#
# rohan.name = "Rohan"
# rohan.salary = 4554
# rohan.role = "Student"

# print(harry.print_det())
# print(rohan.print_det())
print(harry.salary)
print(harry.name)